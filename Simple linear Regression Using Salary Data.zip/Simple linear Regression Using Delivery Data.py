#!/usr/bin/env python
# coding: utf-8

# In[2]:


# import libraries
import pandas as pd
import numpy as np
import seaborn as sns
import statsmodels.formula.api as smf


# In[4]:


# import dataset
dataset=pd.read_csv('C:\\Users\\Admin\\Downloads\\delivery_time (1).CSV')
dataset                               


# In[6]:


##### EDA and Data Visualization
dataset.info()


# In[8]:


sns.distplot(dataset['Delivery Time'])


# In[10]:


sns.distplot(dataset['Sorting Time'])


# In[12]:


##### Feature Engineering
# Renaming Columns
dataset=dataset.rename({'Delivery Time':'delivery_time', 'Sorting Time':'sorting_time'},axis=1)
dataset


# In[14]:


#### Correlation Analysis
dataset.corr()


# In[16]:


sns.regplot(x=dataset['sorting_time'],y=dataset['delivery_time'])


# In[18]:


#### Model Building
model=smf.ols("delivery_time~sorting_time",data=dataset).fit()


# In[20]:


### Model Testing
# Finding Coefficient parameters
model.params


# In[22]:


# Finding tvalues and pvalues
model.tvalues , model.pvalues


# In[24]:


# Finding Rsquared Values
model.rsquared , model.rsquared_adj


# In[26]:


# Manual prediction for say sorting time 5
delivery_time = (6.582734) + (1.649020)*(5)
delivery_time


# In[28]:


# Automatic Prediction for say sorting time 5, 8
new_data=pd.Series([5,8])
new_data


# In[30]:


data_pred=pd.DataFrame(new_data,columns=['sorting_time'])
data_pred


# In[31]:


model.predict(data_pred)

