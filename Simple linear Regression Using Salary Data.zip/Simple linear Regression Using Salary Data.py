#!/usr/bin/env python
# coding: utf-8

# In[32]:


# import libraries
import pandas as pd
import numpy as np
import seaborn as sns
import statsmodels.formula.api as smf


# In[33]:


# import dataset
dataset=pd.read_csv('C:\\Users\\Admin\\Downloads\\Salary_Data (1).CSV')
dataset                               


# In[34]:


##### EDA and Data Visualization
dataset.info()


# In[35]:


sns.distplot(dataset['YearsExperience'])


# In[36]:


sns.distplot(dataset['Salary'])


# In[37]:


##### Feature Engineering
# Renaming Columns
dataset=dataset.rename({'YearsExperience':'years_experience', 'Salary':'salary'},axis=1)
dataset


# In[38]:


#### Correlation Analysis
dataset.corr()


# In[39]:


sns.regplot(x=dataset['years_experience'],y=dataset['salary'])


# In[40]:


#### Model Building
model=smf.ols("years_experience~salary",data=dataset).fit()


# In[41]:


### Model Testing
# Finding Coefficient parameters
model.params


# In[42]:


# Finding tvalues and pvalues
model.tvalues , model.pvalues


# In[43]:


# Finding Rsquared Values
model.rsquared , model.rsquared_adj


# In[44]:


# Manual prediction for say sorting time 5
years_experience = (6.582734) + (1.649020)*(5)
years_experience


# In[45]:


# Automatic Prediction for say sorting time 5, 8
new_data=pd.Series([5,8])
new_data


# In[46]:


data_pred=pd.DataFrame(new_data,columns=['salary'])
data_pred


# In[47]:


model.predict(data_pred)

